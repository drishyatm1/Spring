package com.cts.pms.model;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository
public class ProductDao {

	
	HashMap<Integer, Product> map = new HashMap<Integer, Product>();
	public Integer addProduct(Product product) {
		map.put(product.getProductId(),product);
		return product.getProductId();
		
	}

}
