package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springbootjpa.Person;
import com.cts.springbootjpa.dao.IPersonDao;

@Service
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private IPersonDao dao;//entity mgr factory
	
	@Override
	public List<Person> getAllPersons() {
	
		return dao.findAll();
				
	}

	@Override
	public Optional<Person> getPersonById(int id) {
		
		return dao.findById(id);
	}
	@Override
	public Person getPersonByName(String name) {
		
			return dao.findByPersonName(name);
	}
	@Override
	public Person findUsingNameAddr(String name,String addr){
		return dao.findUsingNameAddr(name,addr);
	}
	
	
	@Override
	public void deleteById(Integer personId) {
		Optional<Person> person = dao.findById(personId);
		
		if(person.isPresent()) {
		dao.deleteById(personId);
		}
		
	}
	
	@Override
	public String add(Person person) {
		
		dao.save(person);
		return "added";
		
	}
	
	@Override
	public Person update(Person person) {
		Optional<Person> per = dao.findById(person.getPersonId());
		Person newPerson = null;
		if(per.isPresent()) {
			newPerson = per.get();
			newPerson.setPersonName(person.getPersonName());
			newPerson.setAddr(person.getAddr());
			newPerson = dao.save(newPerson);
		}
		return newPerson;
		
	}

	
}
